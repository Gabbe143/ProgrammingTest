﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace tbAsteroidExample
{
    class Asteroid
    {
        Texture2D _img;
        Vector2 _pos;
        Vector2 _dir;
        Rectangle _bb;
       
    

        
        public Asteroid(Texture2D img, Vector2 pos, Vector2 dir)
        {
            _img = img;
            _pos = pos;
            _dir = dir;
            _bb = new Rectangle((int)pos.X, (int)pos.Y, img.Width, img.Height);
        }

        public void Update(GameTime gt)
        {
            _pos = _pos + _dir;
            _bb = new Rectangle((int)_pos.X, (int)_pos.Y, _img.Width, _img.Height);
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Draw(_img, _pos, Color.White);
        }

        public bool Hit(int mousePosX, int mousePosY)
        {
            bool hit = false;
            if (_bb.Contains(mousePosX, mousePosY))
            {
                hit = true;
            }

            return hit;
        }
        public float Faster(float pos)
        {
            pos += 1;
            return pos;
        }
    }
}
