﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace tbAsteroidExample
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch; 
        private List<Asteroid> _asteroids;
        Rectangle _Menu;

        Random _RandomAsteroidPos = new Random();
       
        Texture2D _asteroidImg;
        Texture2D _ExplosionImg;

        Vector2 _LeftClickPos;
        Vector2 _StartMenuPos;

        int _ScreenWidth;
        int _screenHeight;

        float _spawnTime;
        float _offsetTime;
        float RandomPosition;

        String START;

        SpriteFont _sf;
        SpriteFont _LC;
        SpriteFont _StartMenu;

        enum GAMESTATE
        {
            menu = 0,
            gameon = 1,
        }

        GAMESTATE _gameState;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            _ScreenWidth = _graphics.PreferredBackBufferWidth = 1920;  // set this value to the desired width of your window
            _screenHeight = _graphics.PreferredBackBufferHeight = 1080;   // set this value to the desired height of your window
            _graphics.ApplyChanges();
            _asteroids = new List<Asteroid>();
            _LeftClickPos = new Vector2(100, 150);
            _StartMenuPos = new Vector2(765, _screenHeight/2);
            _offsetTime = 2000;
            _spawnTime = _offsetTime;
            START = "START";
            //RandomPosition = _RandomAsteroidPos.Next(100, 350);
            _gameState = GAMESTATE.menu;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            _asteroidImg = Content.Load<Texture2D>("astroid");
            _ExplosionImg = Content.Load<Texture2D>("Explosion");

            _sf = Content.Load<SpriteFont>("myfont");
            _LC = Content.Load<SpriteFont>("LeftClick");
            _StartMenu = Content.Load<SpriteFont>("StartMenu");

            for (int i = 0; i < 2; i++)
            {
                //SLUMPTALSGENERATOR FÖR ATT GENERERA NYA POSITIONER OCH RIKTNINGAR
                _asteroids.Add(new Asteroid(_asteroidImg, new Vector2(_RandomAsteroidPos.Next(100, 350), _RandomAsteroidPos.Next(150, 450)), new Vector2(1, 0)));
            }
            _Menu = new Rectangle((int)_StartMenuPos.X, (int)_StartMenuPos.Y, (int)_StartMenu.MeasureString(START).X, (int)_StartMenu.MeasureString(START).Y);
        }

        protected override void Update(GameTime gameTime)
        {
            //RandomPosition = _RandomAsteroidPos.Next(100, 350);
            KeyMouseReader.Update();
            int mx = KeyMouseReader.mouseState.X;
            int my = KeyMouseReader.mouseState.Y;

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (_gameState == GAMESTATE.menu)
            {
                if (KeyMouseReader.LeftClick() && _Menu.Contains(mx,my))
                {
                      _gameState = GAMESTATE.gameon;
                }
            }
            else if (_gameState == GAMESTATE.gameon)
            {
                foreach (Asteroid a in _asteroids)
                {
                    a.Update(gameTime);
                }

                if (KeyMouseReader.LeftClick())
                {
                    //foreach (Asteroid a in _asteroids)
                    //{
                    //    if (a.Hit(mx, my))
                    //    {
                    //        _asteroids.Remove(a);
                    //        break;
                    //    }
                    //}

                    for (int i = _asteroids.Count - 1; i >= 0; i--)
                    {
                        if (_asteroids[i].Hit(mx, my))
                        {
                            _asteroids.RemoveAt(i);
                            //_asteroids[i].Faster(RandomPosition);

                            //_spriteBatch.Draw(_ExplosionImg, // fixa fram asteroids position_asteroids[i].)

                            break;
                        }
                    }
                }

                if (_spawnTime < gameTime.TotalGameTime.TotalMilliseconds)
                {
                    _asteroids.Add(new Asteroid(_asteroidImg, new Vector2(_RandomAsteroidPos.Next(100, 650), _RandomAsteroidPos.Next(150, 850)), new Vector2(_RandomAsteroidPos.Next(-2, 2), _RandomAsteroidPos.Next(-2, 2))));
                    _spawnTime += _offsetTime;
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();
            
            if (_gameState == GAMESTATE.menu)
            {
                _spriteBatch.DrawString(_LC, "Welcome to the game! " +"\n" + " In order to start playing please press START.", _LeftClickPos, Color.White);
                _spriteBatch.DrawString(_StartMenu, "START", _StartMenuPos, Color.White);
            }
            else if (_gameState == GAMESTATE.gameon)
            {
                foreach (Asteroid a in _asteroids)
                {
                    a.Draw(_spriteBatch);
                }

                _spriteBatch.DrawString(_sf, "Num Asteroids: " + _asteroids.Count, new Vector2(100, 50), Color.White);
            }
            _spriteBatch.End();
            

            base.Draw(gameTime);
        }
    }
}
